<?php

if (isset($_GET['page'])) {

   //DATA USER
    if ($_GET['page'] == 'kritik_saran')
       include "page/kritik/kritik_saran.php";
    
    else if ($_GET['page'] == 'sertifikat_penghargaan')
       include "page/sertifikat/sertifikat_penghargaan.php";

    else if ($_GET['page'] == 'tableau_index')
       include "page/visualisasi_data/tableau_index.php";

    else if ($_GET['page'] == 'tableau_assetinfo')
       include "page/visualisasi_data/tableau_assetinfo.php";

    else if ($_GET['page'] == 'tableau_dataop')
       include "page/visualisasi_data/tableau_dataop.php";

    else if ($_GET['page'] == 'tableau_info_bid')
       include "page/visualisasi_data/tableau_info_bid.php";

    else if ($_GET['page'] == 'tableau_kinerja')
       include "page/visualisasi_data/tableau_kinerja.php";

    else if ($_GET['page'] == 'tableau_contoh')
    include "page/visualisasi_data/tableau_contoh.php";



} else {
   include "page/beranda/beranda.php";
    
}

?> 