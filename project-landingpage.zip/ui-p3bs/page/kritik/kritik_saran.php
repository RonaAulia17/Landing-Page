<!-- Contact Section Start -->
<section id="contact" class="section">      
  <div class="contact-form">
    <div class="container">
      <div class="section-header">          
        <h2 class="section-title">Kritik dan Saran</h2>
        <span>UIP3BS</span>
        <p class="section-subtitle">Jangan Ragu Untuk Mengutarakan Kritik dan Saran kepada Kami</p>
      </div>
      <div class="row">          
        <div class="col-lg-9 col-md-9 col-xs-12">
          <div class="contact-block">
            <form id="contactForm">
              <div class="row">
                <div class="col-md-6">
                  <div class="form-group">
                    <input type="text" class="form-control" id="name" name="name" placeholder="Nama Lengkap" required data-error="Please enter your name">
                    <div class="help-block with-errors"></div>
                  </div>                                 
                </div>
                <div class="col-md-6">
                  <div class="form-group">
                    <input type="text" placeholder="Alamat E-Mail" id="email" class="form-control" name="name" required data-error="Please enter your email">
                    <div class="help-block with-errors"></div>
                  </div> 
                </div>
                <div class="col-md-12">
                  <div class="form-group">
                    <input type="text" placeholder="Subjek" id="subject" class="form-control" required data-error="Please enter your subject">
                    <div class="help-block with-errors"></div>
                  </div>
                </div>
                <div class="col-md-12">
                  <div class="form-group"> 
                    <textarea class="form-control" id="message" placeholder="Pesan" rows="7" data-error="Write your message" required></textarea>
                    <div class="help-block with-errors"></div>
                  </div>
                  <div class="submit-button">
                    <button class="btn btn-common btn-effect" id="submit" type="submit">Kirim</button>
                    <div id="msgSubmit" class="h3 hidden"></div> 
                    <div class="clearfix"></div> 
                  </div>
                </div>
              </div>            
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>            
</section>
    <!-- Contact Section End -->