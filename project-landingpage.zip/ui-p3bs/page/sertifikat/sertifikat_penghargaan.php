<!-- Services Section Start -->
<section id="services" class="section">
      <div class="container">
        <div class="section-header">          
          <h2 class="section-title"><br>Sertifikat</h2>
          <p class="section-subtitle" style="color:black; font-size:18px">Berbagai Sertifikat yang Dimiliki Oleh UIP3B Sumatera</p>
        </div>
        <div class="row" >
          <div class="col-lg-4 col-md-6 col-xs-12" >
            <div class="item-boxes services-item wow fadeInDown" data-wow-delay="0.2s" >
              <div class="icon color-1" >
                <!--<i class="lni-pencil"></i>-->
                <a><img src="img/ISO/2014.jpg"
                  style="width:150px;height:150px;"></a>
              </div>
              <h4><b>Sistem Manajemen Aset</b></h4>
              <p style="text-align:justify; color:black">ISO 55001 : 2014 adalah standar ISO yang menetapkan prasyaratan untuk sistem manajemen aset. Standar ini memberikan kerangka kerja untuk pembentukan dan pengaturan tujuan, kebijakan, proses, pemerintahan, dan fasilitas yang terlibat dalam usaha organisasi untuk mencapai tujuan dan sasaran. UIP3BS sendiri berhasil mendapatkan Sertifikat Sistem Manajemen Aset  ISO 55001:2014 pada tanggal 6 April 2018 dan secara konsisten masih mengimplementasikannya hinggga saat ini</p>
            </div>
          </div>
          <div class="col-lg-4 col-md-6 col-xs-12">
            <div class="item-boxes services-item wow fadeInDown" data-wow-delay="0.4s">
              <div class="icon color-2">
                <!--<i class="lni-cog"></i>-->
                <a><img src="img/ISO/2015.jpg"
                  style="width:150px;height:150px;"></a>
              </div>
              <h4><b>Sistem Manajemen Mutu</b></h4>
              <p style="text-align:justify; color:black;">ISO 9001 : 2015 adalah standar ISO yang menetapkan prasyaratan untuk sistem manajemen mutu yang diakui secara internasional. Standa ini menjadi tolok ukur global untuk sistem manajemen mutu. ISO 9001 menetapkan persyaratan dan rekomendasi untuk desain dan penilaian dari suatu sistem manajemen mutu. UIP3BS telah mendapat sertifikat Sistem Manajemen Mutu ISO 9001:2015 pada tanggal 6 Desember 2018 dan akan selalu menjaga konsistensi dalam pengimplementasiannya.
</p>
            </div>
          </div>
          <div class="col-lg-4 col-md-6 col-xs-12" >
            <div class="item-boxes services-item wow fadeInDown" data-wow-delay="0.6s">
              <div class="icon color-3">
                <!--<i class="lni-stats-up"></i>-->
                <a><img src="img/ISO/2018.jpg"
                  style="width:150px;height:150px;"></a>
              </div>
              <h4><b>Sistem Manajamen Kesehatan</b></h4>
              <p style="text-align:justify; color:black;">ISO 45001 : 2018 adalah standar bertaraf internasional yang menetapkan berbagai persyaratan untuk sistem manajemen kesehatan dan keselamatan kerja atau dikenal dengan SMK3. Standar tersebut memungkinkan organisasi untuk aktif meningkatkan kinerja SMK3 untuk mencegah kecelakaan kerja. UIP3BS telah mendapatkan sertifikat PP50/2012 pada tanggal 30 Juli 2018 bersamaan dengan sertifikat Sistem Manajemen K3 selanjutnya mendapatkan sertifikat dari PT PLN Pusertif pada tanggal 10 Januari 2022.</p>
            </div>
          </div>
          <div class="col-lg-4 col-md-6 col-xs-12">
            <div class="item-boxes services-item wow fadeInDown" data-wow-delay="0.8s">
              <div class="icon color-4">
                <!--<i class="lni-layers"></i>-->
                <a><img src="img/ISO/2015(2).jpg"
                  style="width:150px;height:150px;"></a>
              </div>
              <h4><b>Sistem Manajemen Lingkungan</b></h4>
              <p style="text-align:justify; color:black;">ISO 14001 : 2015 (Sistem Manajemen Lingkungan) merupakan sistem manajemen perusahaan yang berfungsi untuk memastikan bahwa proses yang digunakan dan produk yang dihasilkan telah memenuhi komitmen terhadap lingkungan, terutama dalam upaya pemenuhan terhadap peraturan di bidang lingkungan, pencegahan pencemaran dan komitmen terhadap perbaikan berkelanjutan. UIP3BS telah mendapat sertifikat Sistem Manajemen Lingkungan yang dikeluarkan oleh PT PLN PUSERTIF pada tanggal  20 Desember 2019. </p>
            </div>
          </div>
          <div class="col-lg-4 col-md-6 col-xs-12">
            <div class="item-boxes services-item wow fadeInDown" data-wow-delay="1s">
              <div class="icon color-5">
                <!--<i class="lni-tab"></i>-->
                <a><img src="img/ISO/2016.jpg"
                  style="width:150px;height:150px;"></a>
              </div>
              <h4><b>Sistem Manajemen Anti Penyuapan</b></h4>
              <p style="text-align:justify; color:black">ISO 37001 : 2016 (Sistem Manajemen Anti Penyuapan) merupakan sistem yang membantu organisasi mengendalikan praktek penyuapan dengan menyediakan sejumlah langkah penting diantaranya penetapan kebijakan anti-penyuapan, penunjukan petugas yang berkewenangan untuk mengawasi kepatuhan terhadap praktik anti-penyuapan, pembinaan dan pelatihan anggota organisasi, penerapan manajemen resiko pada proyek dan kegiatan organisasi, pengendalian finansial dan komersial, dan pelembagaan laporan prosedur investigasi.</p>
            </div>
          </div>
          <div class="col-lg-4 col-md-6 col-xs-12">
            <div class="item-boxes services-item wow fadeInDown" data-wow-delay="1.2s">
              <div class="icon color-6" >
                <!--<i class="lni-briefcase"></i>-->
                <a><img src="img/ISO/K3.jpg"
                  style="width:150px;height:150px;"></a>
              </div>
              <h4><b>Sistem Manajemen K3</b></h4>
              <p style="text-align:justify; color:black">UIP3S telah menerapkan Sistem Manajemen K3 berdasarkan ISO 45001:2018 dan PP50/2012, di mana sistem membantu manajeken untuk mendorong lingkungan kerja yang sehat dengan menyediakan kerangka kerja untuk mengidentifikasi, mengendalikan, dan mengelola risiko dan peluang yang timbul dari K3. UIP3BS telah mendapatkan sertifikat PP50/2012 pada tanggal 30 Juli 2018 dan sertifikat Sistem Manajemen K3 ISO 45001:2018 oleh Tuv Nord yang selanjutnya mendapatkan sertifikat dari PT PLN Pusertif pada tanggal 10 Januari 2022.</p>
            </div>
          </div>
        </div>
      </div>
    </section>
    <!-- Services Section End -->


    <!-- Features Section Start -->
    <!--
    <section id="features" class="section">
      <div class="container">
        <div class="section-header">          
          <h2 class="section-title">Penghargaan</h2>
          <span>UIP3BS</span>
          <p class="section-subtitle">Berikut Merupakan Prestasi yang Berhasil Diraih Oleh UIP3B Sumatera</p>
        </div>
        <div class="row">
      -->
          <!-- Start featured -->
          <!--
          <div class="col-lg-4 col-md-6 col-xs-12">
            <div class="featured-box">
              <div class="featured-icon">
                <i class="lni-layout"></i>
              </div>
              <div class="featured-content">
                <div class="icon-o"><i class="lni-layout"></i></div>
                <h4>Penghargaan 1</h4>
                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et magna aliqua.</p>
              </div>
            </div>
          </div>
-->
          <!-- End featured -->
          <!-- Start featured -->
          <!--
          <div class="col-lg-4 col-md-6 col-xs-12">
            <div class="featured-box">
              <div class="featured-icon">
                <i class="lni-tab"></i>
              </div>
              <div class="featured-content">
                <div class="icon-o"><i class="lni-tab"></i></div>
                <h4>Penghargaan 2</h4>
                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et magna aliqua.</p>
              </div>
            </div>
          </div>
-->
          <!-- End featured -->
          <!-- Start featured -->
          <!--
          <div class="col-lg-4 col-md-6 col-xs-12">
            <div class="featured-box" >
              <div class="featured-icon">
                <i class="lni-rocket"></i>
              </div>
              <div class="featured-content">
                <div class="icon-o"><i class="lni-rocket"></i></div>
                <h4>Penghargaan 3</h4>
                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et magna aliqua.</p>
              </div>
            </div>
          </div>
-->
          <!-- End featured -->
          <!-- Start featured -->
          <!--
          <div class="col-lg-4 col-md-6 col-xs-12">
            <div class="featured-box">
              <div class="featured-icon">
                <i class="lni-database"></i>
              </div>
              <div class="featured-content">
                <div class="icon-o"><i class="lni-database"></i></div>
                <h4>Penghargaan 4</h4>
                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et magna aliqua.</p>
              </div>
            </div>
          </div>
-->
          <!-- End featured -->
          <!-- Start featured -->
          <!--
          <div class="col-lg-4 col-md-6 col-xs-12">
            <div class="featured-box">
              <div class="featured-icon">
                <i class="lni-leaf"></i>
              </div>
              <div class="featured-content">
                <div class="icon-o"><i class="lni-leaf"></i></div>
                <h4>Penghargaan 5</h4>
                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et magna aliqua.</p>
              </div>
            </div>
          </div>
-->
          <!-- End featured -->
          <!-- Start featured -->
          <!--
          <div class="col-lg-4 col-md-6 col-xs-12">
            <div class="featured-box">
              <div class="featured-icon">
                <i class="lni-pencil"></i>
              </div>
              <div class="featured-content">
                <div class="icon-o"><i class="lni-pencil"></i></div>
                <h4>Penghargaan 6</h4>
                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et magna aliqua.</p>
              </div>
            </div>
          </div>
-->
          <!-- End featured -->
        </div>
      </div>
    </section>
    <!-- Features Section End -->   