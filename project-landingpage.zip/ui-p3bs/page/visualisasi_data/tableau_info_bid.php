 <!-- Start Pricing Table Section -->
 <br>
    <div id="pricing" class="section pricing-section">
      <div class="container">
        <div class="section-header">          
          <h2 class="section-title"><br>Informasi Bidang UIP3B Sumatera</h2>
          <span><!--Visual--></span>
          <p class="section-subtitle">Berikut Merupakan Dashboard Data Visual Untuk Informasi Bidang</p>
        </div>

        <div class="d-flex justify-content-center row">
          
            <div class="col-lg-4 col-md-4 col-xs-12">
              <div class="pricing-table">
                <a><img src="https://upload.wikimedia.org/wikipedia/commons/7/78/Image.jpg"
                  style="width:250px;height:250px;"></a>
                <div class="pricing-details">
                  <div class="price">Bidang Perencanaan</div>
                  <p>
                    Data mengenai Bidang Perencanaan dapat dilihat ***
                  </p>
                </div>
                <div class="plan-button">
                  <a href="index.php?page=tableau_contoh" class="btn btn-common btn-effect">Lihat</a>
                </div>
              </div>
            </div>
  
            <div class="col-lg-4 col-md-4 col-xs-12">
              <div class="pricing-table">
                <a><img src="https://upload.wikimedia.org/wikipedia/commons/7/78/Image.jpg"
                  style="width:250px;height:250px;"></a>
                <div class="pricing-details">
                  <div class="price">Bidang Transmisi</div>
                  <p>
                    Data mengenai Bidang Transmisi dapat dilihat ***
                  </p>
                </div>
                <div class="plan-button">
                  <a href="index.php?page=tableau_contoh" class="btn btn-common btn-effect">Lihat</a>
                </div>
              </div>
            </div>

            <div class="col-lg-4 col-md-4 col-xs-12">
              <div class="pricing-table">
                <a><img src="https://upload.wikimedia.org/wikipedia/commons/7/78/Image.jpg"
                  style="width:250px;height:250px;"></a>
                <div class="pricing-details">
                  <div class="price">Bidang OPSIS</div>
                  <p>
                    Data mengenai Bidang OPSI dapat dilihat ***
                  </p>
                </div>
                <div class="plan-button">
                  <a href="index.php?page=tableau_contoh" class="btn btn-common btn-effect">Lihat</a>
                </div>
              </div>
            </div>
          </div><!--section 1 end-->

          <div class="d-flex justify-content-center">
          
            <div class="col-lg-4 col-md-4 col-xs-12">
              <div class="pricing-table">
                <a><img src="https://upload.wikimedia.org/wikipedia/commons/7/78/Image.jpg"
                  style="width:250px;height:250px;"></a>
                <div class="pricing-details">
                  <div class="price">Bidang PST</div>
                  <p>
                    Data mengenai Bidang PST dapat dilihat ***
                  </p>
                </div>
                <div class="plan-button">
                  <a href="index.php?page=tableau_contoh" class="btn btn-common btn-effect">Lihat</a>
                </div>
              </div>
            </div>
  
            <div class="col-lg-4 col-md-4 col-xs-12">
              <div class="pricing-table">
                <a><img src="https://upload.wikimedia.org/wikipedia/commons/7/78/Image.jpg"
                  style="width:250px;height:250px;"></a>
                <div class="pricing-details">
                  <div class="price">Bidang KKU</div>
                  <p>
                    Data mengenai Bidang KKU dapat dilihat ***
                  </p>
                </div>
                <div class="plan-button">
                  <a href="index.php?page=tableau_contoh" class="btn btn-common btn-effect">Lihat</a>
                </div>
              </div>
            </div>

            <div class="col-lg-4 col-md-4 col-xs-12">
              <div class="pricing-table">
                <a><img src="https://upload.wikimedia.org/wikipedia/commons/7/78/Image.jpg"
                  style="width:250px;height:250px;"></a>
                <div class="pricing-details">
                  <div class="price">Biro Pengadaan</div>
                  <p>
                    Data mengenai Biro Pengadaan dapat dilihat ***
                  </p>
                </div>
                <div class="plan-button">
                  <a href="index.php?page=tableau_contoh" class="btn btn-common btn-effect">Lihat</a>
                </div>
              </div>
            </div>
          </div><!--section 2 end-->

          <div class="d-flex justify-content-center">
          
            <div class="col-lg-4 col-md-4 col-xs-12">
              <div class="pricing-table">
                <a><img src="https://upload.wikimedia.org/wikipedia/commons/7/78/Image.jpg"
                  style="width:250px;height:250px;"></a>
                <div class="pricing-details">
                  <div class="price">Biro K3L</div>
                  <p>
                    Data mengenai Biro K3L dapat dilihat ***
                  </p>
                </div>
                <div class="plan-button">
                  <a href="index.php?page=tableau_contoh" class="btn btn-common btn-effect">Lihat</a>
                </div>
              </div>
            </div>
  
          </div>
        
          

      </div>
    </div>
    <!-- End Pricing Table Section -->