<!-- Start Pricing Table Section -->
<br>
    <div id="pricing" class="section pricing-section">
      <div class="container">
        <div class="section-header">          
          <h2 class="section-title"><br>Kinerja UIP3B Sumatera</h2>
          <span><!--Visual--></span>
          <p class="section-subtitle">Berikut Merupakan Dashboard Data Visual Untuk Kinerja</p>
        </div>

        <div class="d-flex justify-content-center row">
          
            <div class="col-lg-4 col-md-4 col-xs-12">
              <div class="pricing-table">
                <a><img src="https://upload.wikimedia.org/wikipedia/commons/7/78/Image.jpg"
                  style="width:250px;height:250px;"></a>
                <div class="pricing-details">
                  <div class="price">Kinerja UPT</div>
                  <p>
                    Kinerja UPT dapat dilihat ***
                  </p>
                </div>
                <div class="plan-button">
                  <a href="index.php?page=tableau_contoh" class="btn btn-common btn-effect">Lihat</a>
                </div>
              </div>
            </div>
  
            <div class="col-lg-4 col-md-4 col-xs-12">
              <div class="pricing-table">
                <a><img src="https://upload.wikimedia.org/wikipedia/commons/7/78/Image.jpg"
                  style="width:250px;height:250px;"></a>
                <div class="pricing-details">
                  <div class="price">Kinerja UP2B</div>
                  <p>
                    Kinerja UP2B dapat dilihat ***
                  </p>
                </div>
                <div class="plan-button">
                  <a href="index.php?page=tableau_contoh" class="btn btn-common btn-effect">Lihat</a>
                </div>
              </div>
            </div>
          </div>
        
          

      </div>
    </div>
    <!-- End Pricing Table Section -->