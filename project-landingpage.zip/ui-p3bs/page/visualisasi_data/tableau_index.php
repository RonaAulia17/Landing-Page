<!-- Start Pricing Table Section -->
    <div id="pricing" class="section pricing-section">
      <div class="container">
        <div class="section-header">          
          <h2 class="section-title">Data Aset UIP3B Sumatera</h2>
          <span><!--Visual--></span>
          <p class="section-subtitle"><br>Berikut Merupakan Dashboard Data Visual Milik UIP3B Sumatera</p>
        </div>

        <div class="container">

          <div class="d-flex justify-content-center row">
          
            <div class="col-lg-4 col-md-4 col-xs-12">
              <div class="pricing-table">
                <a><img src="https://upload.wikimedia.org/wikipedia/commons/7/78/Image.jpg"
                  style="width:250px;height:250px;"></a>
                <div class="pricing-details">
                  <div class="price">Aset Information</div>
                  <p>
                    Aset information merupakan ***
                  </p>
                </div>
                <div class="plan-button">
                  <a href="index.php?page=tableau_assetinfo" class="btn btn-common btn-effect">Lihat</a>
                </div>
              </div>
            </div>
  
            <div class="col-lg-4 col-md-4 col-xs-12">
              <div class="pricing-table">
                <a><img src="https://upload.wikimedia.org/wikipedia/commons/7/78/Image.jpg"
                  style="width:250px;height:250px;"></a>
                <div class="pricing-details">
                  <div class="price">Data Operasional</div>
                  <p>
                    Data operasional merupakan ***
                  </p>
                </div>
                <div class="plan-button">
                  <a href="index.php?page=tableau_dataop" class="btn btn-common btn-effect">Lihat</a>
                </div>
              </div>
            </div>
          </div>

          <div class="d-flex justify-content-center row">
          
            <div class="col-lg-4 col-md-4 col-xs-12">
              <div class="pricing-table">
                <a><img src="https://upload.wikimedia.org/wikipedia/commons/7/78/Image.jpg"
                  style="width:250px;height:250px;"></a>
                <div class="pricing-details">
                  <div class="price">Kinerja</div>
                  <p>
                    Kinerja yang telah ***
                  </p>
                </div>
                <div class="plan-button">
                  <a href="index.php?page=tableau_kinerja" class="btn btn-common btn-effect">Lihat</a>
                </div>
              </div>
            </div>
  
            <div class="col-lg-4 col-md-4 col-xs-12">
              <div class="pricing-table">
                <a><img src="https://upload.wikimedia.org/wikipedia/commons/7/78/Image.jpg"
                  style="width:250px;height:250px;"></a>
                <div class="pricing-details">
                  <div class="price">Informasi Bidang</div>
                  <p>
                    Informasi bidang yang dimiliki ***
                  </p>
                </div>
                <div class="plan-button">
                  <a href="index.php?page=tableau_info_bid" class="btn btn-common btn-effect">Lihat</a>
                </div>
              </div>
            </div>
          </div>

         
        </div>

      </div>
    </div>
    <!-- End Pricing Table Section -->