 <!-- Main Carousel Section -->
    <div id="carousel-area">

      <div id="carousel-slider" class="carousel slide carousel-fade" data-ride="carousel">
        
        <div class="carousel-inner" role="listbox">
          
      
            <div class="carousel-item active ">

              <img src="img/slider/gedung-uip3bs-5.jpg" alt="">
              <div class="carousel-caption text-center">
                <img src="img/logo/logo-smt.png" alt="logosmt" width="150" height="173" >
                <h3 class="wow fadeInDown" data-wow-delay="0.3s">Sistem Manajemen Terintegrasi</h3>
                <h2 class="wow bounceIn" data-wow-delay="0.6s">UIP3B Sumatera</h2> 
                <h4 class="wow fadeInUp" data-wow-delay="0.9s">"Electricity for a Better Life"</h4>
                <a href="#" class="btn btn-lg btn-common btn-effect wow fadeInUp" data-wow-delay="1.2s">View Profile</a>

              </div>
            </div>

            
          </div>
          
        </div>
      </div> 

    <!-- Profil Perusahaan Start -->
    <section class="call-action section">
      <div class="container">
        <div class="row justify-content-center">
          <div class="col-10">
            <div class="section-header">          
              <h2 class="section-title">Profil Singkat</h2>
              <p class="section-subtitle" style="text-align:justify; font-size:20px; color:black;">PT PLN (Persero) P3B Sumatera merupakan salah satu unit bisnis PT PLN (Persero) yang dibentuk pada tanggal 24 Agustus 2004 berdasarkan SK Dir No. 179.K/010/DIR.2004 dan beroperasi secara resmi tanggal 25 April 2005 dengan produk utama berupa jasa penyaluran dan pengoperasian sistem tenaga listrik  yang handal, efisien dan ekonomis serta penyampaian produk  ke pelanggan dengan mekanisme TSA (Transmission Service Agreement) dan PSA (Power Sales Agreement).<br><br>PT PLN (Persero) P3B Sumatera membawahi 8 (delapan) Unit Pelayanan Transmisi (UPT) dan 3 (tiga) Unit Pengatur Beban (UPB). PT PLN (Persero) P3B Sumatera-UPT Pekanbaru merupakan salah satu Unit Organisasi yang berada di bawah PT PLN (Persero) P3B Sumatera yang dibentuk berdasarkan SK Direksi PT PLN (Persero) nomor 341.K/DIR/2008 tanggal 28 Oktober 2008.<br><br>PT PLN (Persero) P3B Sumatera-UPT Pekanbaru memulai operasional oganisasinya pada awal Juni 2009 dengan kantor bertempat di Jl. Siak II Air Hitam Km 11 Garuda Sakti Pekanbaru yang berada dilokasi GI Garuda Sakti.


</p>
            </div>
            
          </div>
        </div>
      </div>
    </section>
    <!-- Profil Perusahaan Start End -->

    <!-- Start Video Profil -->
    <section class="video-promo section bg-defult">
      <div class="overlay"></div>
      <div class="container">
        <div class="row">
          <div class="col-md-12 col-sm-12">
              <div class="video-promo-content text-center">
                <a href="https://www.youtube.com/watch?v=E6-GcXiZnc0" class="video-popup"><i class="lni-film-play"></i></a>
                <h2 class="wow zoomIn" data-wow-duration="1000ms" data-wow-delay="100ms">Video Profil</h2>
                <p class="wow zoomIn" data-wow-duration="1000ms" data-wow-delay="100ms">Mari Berkenalan dengan UIP3B Sumatera</p>
              </div>
          </div>
        </div>
      </div>
    </section>
    <!-- End Video Profil -->

    <!-- STRUKTUR section Start -->
    <div class="container">
        <div class="section-header">
            <br><br><br>
            <h2 class="section-title">Struktur Organisasi</h2>
        </div>
      <div class="container" style="overflow-x:auto">
        
      <p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
      <img src="img/struktur_org/struk_org.png" style="width:1050px;">
      </p>
<br><br><br><br><br>
      </div>
  
    </div>
    
    <!--
    <section id="team" class="section">
      <div class="container">
        <div class="section-header">          
          <h2 class="section-title">Struktur Organisasi</h2>
          
          <p class="section-subtitle">Instansi yang Kuat Pasti Memiliki Orang-Orang yang Hebat</p>
        </div>
        <div class="row">
          <div class="col-lg-3 col-md-6 col-xs-12">
            <div class="single-team">
              <img src="https://awsimages.detik.net.id/customthumb/2013/02/20/1133/191418_kerja.jpg?w=700&q=90"
             >
              <div class="team-details">
                <div class="team-inner">
                  <h4 class="team-title">Nama</h4>
                  <p>Jabatan</p>
                  <ul class="social-list">
                    <li class="facebook"><a href="#"><i class="lni-facebook-filled"></i></a></li>
                    <li class="twitter"><a href="#"><i class="lni-twitter-filled"></i></a></li>
                    <li class="google-plus"><a href="#"><i class="lni-google-plus"></i></a></li>
                    <li class="linkedin"><a href="#"><i class="lni-linkedin-fill"></i></a></li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
          <div class="col-lg-3 col-md-6 col-xs-12">
            <div class="single-team">
              <img src="https://awsimages.detik.net.id/customthumb/2013/02/20/1133/191418_kerja.jpg?w=700&q=90"
             >
              <div class="team-details">
                <div class="team-inner">
                  <h4 class="team-title">Nama</h4>
                  <p>Jabatan</p>
                  <ul class="social-list">
                    <li class="facebook"><a href="#"><i class="lni-facebook-filled"></i></a></li>
                    <li class="twitter"><a href="#"><i class="lni-twitter-filled"></i></a></li>
                    <li class="google-plus"><a href="#"><i class="lni-google-plus"></i></a></li>
                    <li class="linkedin"><a href="#"><i class="lni-linkedin-fill"></i></a></li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
          <div class="col-lg-3 col-md-6 col-xs-12">
            <div class="single-team">
              <img src="https://awsimages.detik.net.id/customthumb/2013/02/20/1133/191418_kerja.jpg?w=700&q=90"
             >
              <div class="team-details">
                <div class="team-inner">                  
                  <h4 class="team-title">Nama</h4>
                  <p>Jabatan</p>
                  <ul class="social-list">
                    <li class="facebook"><a href="#"><i class="lni-facebook-filled"></i></a></li>
                    <li class="twitter"><a href="#"><i class="lni-twitter-filled"></i></a></li>
                    <li class="google-plus"><a href="#"><i class="lni-google-plus"></i></a></li>
                    <li class="linkedin"><a href="#"><i class="lni-linkedin-fill"></i></a></li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
          <div class="col-lg-3 col-md-6 col-xs-12">
            <div class="single-team">
              <img src="https://awsimages.detik.net.id/customthumb/2013/02/20/1133/191418_kerja.jpg?w=700&q=90"
             >
              <div class="team-details">
                <div class="team-inner">
                  <h4 class="team-title">Nama</h4>
                  <p>Jabatan</p>
                  <ul class="social-list">
                    <li class="facebook"><a href="#"><i class="lni-facebook-filled"></i></a></li>
                    <li class="twitter"><a href="#"><i class="lni-twitter-filled"></i></a></li>
                    <li class="google-plus"><a href="#"><i class="lni-google-plus"></i></a></li>
                    <li class="linkedin"><a href="#"><i class="lni-linkedin-fill"></i></a></li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
    -->
    <!-- STRUKTUR section End -->


    <!-- VISI MISI to Action Start -->
    <div class="container">
        <div class="row justify-content-center">
          <div class="col-10">
            <div class="section-header">          
              <h2 class="section-title">Visi dan Misi</h2>
            </div>
            <div class="cta-trial text-center">
              <h4>Visi</h4>
              <p style="font-size: 20px; color:black" >Menjadi Perusahaan Listrik Terkemuka se-Asia Tenggara dan #1 Pilihan Pelanggan Untuk Solusi Energi</p><br><br>
              <h4>Misi</h4>

        <div class="d-flex justify-content-center row">
          
            <div class="col-lg-4 col-md-6 col-xs-12">
                <div class="item-boxes services-item wow fadeInDown" data-wow-delay="0.2s">
                  <div class="icon color-1">
                <i>1</i>
                  </div>
                    <h4 style="text-align:center">Mengelola operasi sistem tenaga listrik secara andal</h4>
                </div>
            </div>
         
        </div>

        <div class="d-flex justify-content-center row">
          
            
            <div class="col-lg-4 col-md-6 col-xs-12">
            <div class="item-boxes services-item wow fadeInDown" data-wow-delay="0.2s">
              <div class="icon color-2">
                <i>2</i>
              </div>
              <h4 style="text-align:center">Melaksanakan pemeliharaan instalasi sistem transmisi tenaga listrik Sumatera</h4>
            </div>
            </div>
         
        </div>

        <div class="d-flex justify-content-center row">
          
            <div class="col-lg-4 col-md-6 col-xs-12">
                <div class="item-boxes services-item wow fadeInDown" data-wow-delay="0.2s">
                  <div class="icon color-3">
                <i>3</i>
                  </div>
                    <h4 style="text-align:center">Mengelola transaksi tenaga listrik secara kompetitif, transparan dan adil</h4>
                </div>
            </div>
         
        </div>
        <div class="d-flex justify-content-center row">
          
  
            <div class="col-lg-4 col-md-6 col-xs-12">
            <div class="item-boxes services-item wow fadeInDown" data-wow-delay="0.2s">
              <div class="icon color-4">
                <i>4</i>
              </div>
              <h4 style="text-align:center">Melaksanakan pemeliharaan instalasi sistem transmisi tenaga listrik Sumatera</h4>
            </div>
            </div>
         
        </div>
      
   
            </div>
          </div>
        </div>
      </div>
    
    
    <!-- VISI MISI to Action End -->


    <!-- KOMITMEN Section Start -->
    <section id="services" class="section">
      <div class="container">
        <div class="section-header">          
          <h2 class="section-title">Komitmen</h2>
          
          <p class="section-subtitle">Kami Segenap Tim dari UIP3B Sumatera Selalu Berkomitmen Untuk:</p>
        </div>
        <div class="row">
          <div class="col-lg-4 col-md-6 col-xs-12">
            <div class="item-boxes services-item wow fadeInDown" data-wow-delay="0.2s">
              <div class="icon color-1">
                <i class="lni-pencil"></i>
              </div>
              <h4>Komitmen 1</h4>
              <p>Kami berkomitmen untuk ***</p>
            </div>
          </div>
          <div class="col-lg-4 col-md-6 col-xs-12">
            <div class="item-boxes services-item wow fadeInDown" data-wow-delay="0.4s">
              <div class="icon color-2">
                <i class="lni-cog"></i>
              </div>
              <h4>Komitmen 2</h4>
              <p>Kami berkomitmen untuk ***</p>
            </div>
          </div>
          <div class="col-lg-4 col-md-6 col-xs-12">
            <div class="item-boxes services-item wow fadeInDown" data-wow-delay="0.6s">
              <div class="icon color-3">
                <i class="lni-stats-up"></i>
              </div>
              <h4>Komitmen 3</h4>
              <p>Kami berkomitmen untuk ***</p>
            </div>
          </div>
          <div class="col-lg-4 col-md-6 col-xs-12">
            <div class="item-boxes services-item wow fadeInDown" data-wow-delay="0.8s">
              <div class="icon color-4">
                <i class="lni-layers"></i>
              </div>
              <h4>Komitmen 4</h4>
              <p>Kami berkomitmen untuk ***</p>
            </div>
          </div>
          <div class="col-lg-4 col-md-6 col-xs-12">
            <div class="item-boxes services-item wow fadeInDown" data-wow-delay="1s">
              <div class="icon color-5">
                <i class="lni-tab"></i>
              </div>
              <h4>Komitmen 5</h4>
              <p>Kami berkomitmen untuk ***</p>
            </div>
          </div>
          <div class="col-lg-4 col-md-6 col-xs-12">
            <div class="item-boxes services-item wow fadeInDown" data-wow-delay="1.2s">
              <div class="icon color-6">
                <i class="lni-briefcase"></i>
              </div>
              <h4>Komitmen 6</h4>
              <p>Kami berkomitmen untuk ***</p>
            </div>
          </div>
        </div>
      </div>
    </section>
    <!-- KOMITMEN Section End -->


    <!-- KEBIJAKAN Section Start -->
    <section id="features" class="section">
      <div class="container">
        <div class="section-header">          
          <h2 class="section-title">Kebijakan SMT</h2>
         
          <p class="section-subtitle">Beberapa Kebijakan Terkait Sistem Manajemen Terintegrasi (SMT)</p>
        </div>
        <div class="row">
          <!-- Start featured -->
          <div class="col-lg-4 col-md-6 col-xs-12">
            <div class="featured-box">
              <div class="featured-icon">
                <i class="lni-layout"></i>
              </div>
              <div class="featured-content">
                <div class="icon-o"><i class="lni-layout"></i></div>
                <h4>Kebijakan 1</h4>
                <p>Kebijakan ini terkait ***</p>
              </div>
            </div>
          </div>
          <!-- End featured -->
          <!-- Start featured -->
          <div class="col-lg-4 col-md-6 col-xs-12">
            <div class="featured-box">
              <div class="featured-icon">
                <i class="lni-tab"></i>
              </div>
              <div class="featured-content">
                <div class="icon-o"><i class="lni-tab"></i></div>
                <h4>Kebijakan 2</h4>
                <p>Kebijakan ini terkait ***</p>
              </div>
            </div>
          </div>
          <!-- End featured -->
          <!-- Start featured -->
          <div class="col-lg-4 col-md-6 col-xs-12">
            <div class="featured-box">
              <div class="featured-icon">
                <i class="lni-rocket"></i>
              </div>
              <div class="featured-content">
                <div class="icon-o"><i class="lni-rocket"></i></div>
                <h4>Kebijakan 3</h4>
                <p>Kebijakan ini terkait ***</p>
              </div>
            </div>
          </div>
          <!-- End featured -->
          <!-- Start featured -->
          <div class="col-lg-4 col-md-6 col-xs-12">
            <div class="featured-box">
              <div class="featured-icon">
                <i class="lni-database"></i>
              </div>
              <div class="featured-content">
                <div class="icon-o"><i class="lni-database"></i></div>
                <h4>Kebijakan 4</h4>
                <p>Kebijakan ini terkait ***</p>
              </div>
            </div>
          </div>
          <!-- End featured -->
          <!-- Start featured -->
          <div class="col-lg-4 col-md-6 col-xs-12">
            <div class="featured-box">
              <div class="featured-icon">
                <i class="lni-leaf"></i>
              </div>
              <div class="featured-content">
                <div class="icon-o"><i class="lni-leaf"></i></div>
                <h4>Kebijakan 5</h4>
                <p>Kebijakan ini terkait ***</p>
              </div>
            </div>
          </div>
          <!-- End featured -->
          <!-- Start featured -->
          <div class="col-lg-4 col-md-6 col-xs-12">
            <div class="featured-box">
              <div class="featured-icon">
                <i class="lni-pencil"></i>
              </div>
              <div class="featured-content">
                <div class="icon-o"><i class="lni-pencil"></i></div>
                <h4>Kebijakan 6</h4>
                <p>Kebijakan ini terkait ***</p>
              </div>
            </div>
          </div>
          <!-- End featured -->
        </div>
      </div>
    </section>
    <!-- KEBIJAKAN Section End -->  


    <!-- SASARAN MUTU Pricing Table Section -->
    <div id="pricing" class="section pricing-section">
      <div class="container">
        <div class="section-header">          
          <h2 class="section-title">Sasaran Mutu</h2>
          
          <p class="section-subtitle">Sasaran Mutu yang Selalu Ingin Kami Wujudkan ***</p>
        </div>

        <div class="row pricing-tables">
          <div class="col-lg-4 col-md-4 col-xs-12">
            <div class="pricing-table">
              <div class="pricing-details">
                <h2>Mutu</h2>
                <div class="price">Mutu<span>1</span></div>
                <ul>
                  <li>Consectetur adipiscing</li>
                  <li>Nunc luctus nulla et tellus</li>
                  <li>Suspendisse quis metus</li>
                  <li>Vestibul varius fermentum erat</li>
                  <li> - </li>
                </ul>
              </div>
              <!--<div class="plan-button">
                <a href="#" class="btn btn-common btn-effect">Get Plan</a>
              </div>-->
            </div>
          </div>

          <div class="col-lg-4 col-md-4 col-xs-12">
            <div class="pricing-table pricing-big">
              <div class="pricing-details">
                <h2>Mutu</h2>
                <div class="price">Mutu<span>2</span></div>
                <ul>
                  <li>Consectetur adipiscing</li>
                  <li>Nunc luctus nulla et tellus</li>
                  <li>Suspendisse quis metus</li>
                  <li>Vestibul varius fermentum erat</li>
                  <li> - </li>
                </ul>
              </div>
              <!--<div class="plan-button">
                <a href="#" class="btn btn-common btn-effect">Buy Now</a>
              </div>-->
            </div>
          </div>

          <div class="col-lg-4 col-md-4 col-xs-12">
            <div class="pricing-table">
              <div class="pricing-details">
                <h2>Mutu</h2>
                <div class="price">Mutu<span>3</span></div>
                <ul>
                  <li>Consectetur adipiscing</li>
                  <li>Nunc luctus nulla et tellus</li>
                  <li>Suspendisse quis metus</li>
                  <li>Vestibul varius fermentum erat</li>
                  <li>Suspendisse quis metus</li>
                </ul>
              </div>
              <!--<div class="plan-button">
                <a href="#" class="btn btn-common btn-effect">Buy Now</a>
              </div>-->
            </div>
          </div>

        </div>
      </div>
    </div>
    <!-- SASARAN MUTU Section -->


    <!-- Counter Section Start -->
    <div class="counters section bg-defult">
      <div class="container">
        <div class="row"> 

          

          <div class="col-md-6 ">
            <div class="facts-item">
              <div class="icon">
                <i class="lni-bar-chart"></i>
              </div>                
              <div class="fact-count">
                <h3><span class="counter">100</span></h3>
                <h4>Pengunjung</h4>
              </div>
            </div>
          </div>

          <div class="col-md-6 ">
            <div class="facts-item">
              <div class="icon">
                <i class="lni-user"></i>
              </div>                
              <div class="fact-count">
                <h3><span class="counter">1500</span></h3>
                <h4>Pegawai</h4>
              </div>
            </div>
          </div>


        </div>
      </div>
    </div>
    <!-- Counter Section END -->
